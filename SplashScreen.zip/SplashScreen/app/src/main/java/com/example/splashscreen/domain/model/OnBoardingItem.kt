package com.example.splashscreen.domain.model

data class OnBoardingItem (
    val description:String,
    val title : String,
    val onBoardingImage :Int
    )